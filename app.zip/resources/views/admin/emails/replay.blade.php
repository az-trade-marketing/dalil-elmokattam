
    <h1>Hello, {{ $name }}</h1>
    <p>{{ $reply }}</p>
    <p>Thank you for contacting us.</p>

